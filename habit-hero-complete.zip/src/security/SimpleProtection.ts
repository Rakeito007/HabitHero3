import { simpleSecurityManager } from './SimpleSecurityManager';

// Simple protected function wrapper
export function simpleProtectedFunction<T extends any[], R>(
  fn: (...args: T) => R,
  name: string
): (...args: T) => R {
  return (...args: T): R => {
    try {
      // Simple validation
      if (!simpleSecurityManager.validateOperation(name)) {
        throw new Error(`Operation ${name} blocked by security`);
      }
      
      // Execute the function
      const result = fn(...args);
      
      return result;
    } catch (error) {
      console.warn(`Protected function ${name} failed:`, error);
      
      // Record violation only for subscription-related operations
      if (name.includes('Subscription') || name.includes('addHabit')) {
        simpleSecurityManager.recordViolation(`${name} failed`);
      }
      
      throw error;
    }
  };
}

// Constants without encryption
export const SIMPLE_CONSTANTS = {
  FREE_PLAN: 'free',
  MONTHLY_PLAN: 'monthly', 
  LIFETIME_PLAN: 'lifetime',
  MAX_FREE_HABITS: 3,
};